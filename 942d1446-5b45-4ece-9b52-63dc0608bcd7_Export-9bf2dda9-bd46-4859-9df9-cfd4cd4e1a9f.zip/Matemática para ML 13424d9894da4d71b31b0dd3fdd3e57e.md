# Matemática para ML

[Linear Algebra](Matema%CC%81tica%20para%20ML%2013424d9894da4d71b31b0dd3fdd3e57e/Linear%20Algebra%209b11884ccccf4ebeba67f30b4dc52209.md)